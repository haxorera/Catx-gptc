module.exports.config = {
    name: "banned",
    version: "2.0.0",
    permission: 2,
    credits: "EMon-BHai (Modified by ChatGPT)",
    prefix: true,
    description: "Show list of banned users or banned threads",
    category: "admin",
    usages: "banned [user/thread]",
    cooldowns: 5,
};

module.exports.run = async function ({ api, args, Users, event, Threads }) {

    if (!args[0])
        return api.sendMessage(
            "❗ Correct Usage:\n\n• banned user\n• banned thread",
            event.threadID,
            event.messageID
        );

    // ===============================
    // 📌 USER BAN LIST
    // ===============================
    if (args[0] === "user") {
        const banList = global.data.userBanned || [];
        const bannedUsers = [];

        for (const uid of banList) {
            const data = await Users.getData(uid);
            if (data?.banned === 1) bannedUsers.push(uid);
        }

        if (bannedUsers.length === 0)
            return api.sendMessage("✅ No users are currently banned.", event.threadID, event.messageID);

        let msg = "📌 **List of Banned Users:**\n\n";

        for (let i = 0; i < bannedUsers.length; i++) {
            const uid = bannedUsers[i];
            const info = await Users.getData(uid);
            msg += `${i + 1}. Name: ${info?.name || "Unknown"}\n   ID: ${uid}\n\n`;
        }

        return api.sendMessage(msg, event.threadID, event.messageID);
    }

    // ===============================
    // 📌 THREAD BAN LIST
    // ===============================
    else if (args[0] === "thread") {
        const banList = global.data.threadBanned || [];
        const bannedThreads = [];

        for (const tid of banList) {
            const data = await Threads.getData(tid);
            if (data?.banned === 1) bannedThreads.push(tid);
        }

        if (bannedThreads.length === 0)
            return api.sendMessage("✅ No threads are currently banned.", event.threadID, event.messageID);

        let msg = "📌 **List of Banned Threads:**\n\n";

        for (let i = 0; i < bannedThreads.length; i++) {
            const tid = bannedThreads[i];
            const info = await api.getThreadInfo(tid);
            msg += `${i + 1}. Thread Name: ${info?.threadName || "Unknown"}\n   ID: ${tid}\n\n`;
        }

        return api.sendMessage(msg, event.threadID, event.messageID);
    }

    // ===============================
    // ❌ WRONG PARAMETERS
    // ===============================
    else {
        return api.sendMessage(
            "❗ Invalid option.\nUse:\n• banned user\n• banned thread",
            event.threadID,
            event.messageID
        );
    }
};
