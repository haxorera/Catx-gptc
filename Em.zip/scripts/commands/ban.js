const fs = require("fs");
const path = require("path");

module.exports.config = {
    name: "ban",
    version: "1.0.1",
    permission: 2,
    credits: "EMon-BHai",
    prefix: true,
    description: "Local ban system",
    category: "admin",
    usages: "ban add/remove/list",
    cooldowns: 3,
};

// 📌 Auto detect EMon-BHai folder
const banFolder = path.join(process.cwd(), "EMon-BHai");
const banFile = path.join(banFolder, "ban.json");

// 📌 Ensure folder + file exists
function ensureBanFile() {
    if (!fs.existsSync(banFolder)) {
        fs.mkdirSync(banFolder, { recursive: true });
    }
    if (!fs.existsSync(banFile)) {
        fs.writeFileSync(banFile, JSON.stringify([], null, 4));
    }
}

// 📌 Load JSON
function loadBanData() {
    ensureBanFile();
    return JSON.parse(fs.readFileSync(banFile));
}

// 📌 Save JSON
function saveBanData(data) {
    ensureBanFile();
    fs.writeFileSync(banFile, JSON.stringify(data, null, 4));
}

module.exports.run = async function ({ api, event, args, Users }) {
    ensureBanFile();

    const action = args[0];
    const uid = args[1];

    let data = loadBanData();

    // =============================
    // 📌 ban list
    // =============================
    if (action === "list") {
        if (data.length === 0) {
            return api.sendMessage("✔ No banned users found in local system.", event.threadID);
        }

        let msg = "📜 LOCAL BAN LIST\n\n";
        data.forEach((u, i) => {
            msg += `${i + 1}. ${u.name}\n🆔 ${u.uid}\n📛 Reason: ${u.reason}\n📅 Date: ${u.date}\n\n`;
        });

        return api.sendMessage(msg, event.threadID);
    }

    // =============================
    // 📌 ban add <uid> reason
    // =============================
    if (action === "add") {
        if (!uid) return api.sendMessage("❗ Usage: ban add <uid> <reason>", event.threadID);

        const reason = args.slice(2).join(" ") || "No reason provided";

        if (data.some(u => u.uid === uid)) {
            return api.sendMessage("⚠ User already banned.", event.threadID);
        }

        const userName = await Users.getNameUser(uid).catch(() => "Unknown User");

        const entry = {
            uid,
            name: userName,
            reason,
            date: new Date().toLocaleString("en-US", { timeZone: "Asia/Dhaka" })
        };

        data.push(entry);
        saveBanData(data);

        return api.sendMessage(
            `🚫 USER HAS BEEN BANNED\n\n👤 Name: ${entry.name}\n🆔 UID: ${uid}\n📛 Reason: ${reason}\n📅 Date: ${entry.date}`,
            event.threadID
        );
    }

    // =============================
    // 📌 ban remove <uid>
    // =============================
    if (action === "remove") {
        if (!uid) return api.sendMessage("❗ Usage: ban remove <uid>", event.threadID);

        const index = data.findIndex(u => u.uid === uid);

        if (index === -1) {
            return api.sendMessage("⚠ User is not banned.", event.threadID);
        }

        const removed = data[index];
        data.splice(index, 1);
        saveBanData(data);

        return api.sendMessage(
            `✅ USER UNBANNED SUCCESSFULLY\n\n👤 Name: ${removed.name}\n🆔 UID: ${uid}`,
            event.threadID
        );
    }

    // 📌 Default error
    return api.sendMessage("❗ Invalid usage.\nUse:\n• ban add <uid> <reason>\n• ban remove <uid>\n• ban list", event.threadID);
};