module.exports = function({ api, models }) {

setInterval(function () {
  if(global.config.notification) {
    require("./handle/handleNotification.js")({ api });
  }
}, 1000*60);

const Users = require("./controllers/users")({ models, api }),
      Threads = require("./controllers/threads")({ models, api }),
      Currencies = require("./controllers/currencies")({ models });

const logger = require("../catalogs/Emonc.js");
const chalk = require("chalk");
const gradient = require("gradient-string");
const crayon = gradient('yellow', 'lime', 'green');
const sky = gradient('#3446eb', '#3455eb', '#3474eb');

(async function () {
  try {

    const [threads, users] = await Promise.all([
      Threads.getAll(),
      Users.getAll(['userID', 'name', 'data'])
    ]);

    threads.forEach(data => {
      const idThread = String(data.threadID);
      global.data.allThreadID.push(idThread);
      global.data.threadData.set(idThread, data.data || {});
      global.data.threadInfo.set(idThread, data.threadInfo || {});

      if (data.data && data.data.commandBanned?.length) {
        global.data.commandBanned.set(idThread, data.data.commandBanned);
      }

      if (data.data && data.data.NSFW) {
        global.data.threadAllowNSFW.push(idThread);
      }
    });

    users.forEach(dataU => {
      const idUsers = String(dataU.userID);
      global.data.allUserID.push(idUsers);

      if (dataU.name) {
        global.data.userName.set(idUsers, dataU.name);
      }

      if (dataU.data?.banned) {
        global.data.userBanned.set(idUsers, {
          reason: dataU.data.reason || "",
          dateAdded: dataU.data.dateAdded || ""
        });
      }

      if (dataU.data?.commandBanned?.length) {
        global.data.commandBanned.set(idUsers, dataU.data.commandBanned);
      }
    });

    global.loading(
      `deployed ${chalk.blueBright(global.data.allThreadID.length)} groups and `
      + `${chalk.blueBright(global.data.allUserID.length)} users\n\n`
      + `${chalk.blue("EMon-BHai-Bot Running")}\n`,
      "data"
    );

  } catch (error) {
    logger.loader(`can't load environment variable, error : ${error}`, 'error');
  }
})();


const operator = global.config.OPERATOR.length;
const admin = global.config.ADMINBOT.length;
const approved = global.config.APPROVED.length;

console.log(
  `${sky("data -")} bot name : ${chalk.blueBright(global.config.BOTNAME || "Emon")}\n`
  + `${sky("data -")} bot id : ${chalk.blueBright(api.getCurrentUserID())}\n`
  + `${sky("data -")} bot prefix : ${chalk.blueBright(global.config.PREFIX)}\n`
  + `${sky("data -")} deployed ${chalk.blueBright(operator)} bot operators and `
  + `${chalk.blueBright(admin)} admins`
);

if (global.config.approval) {
  console.log(`${sky("data -")} deployed ${chalk.blueBright(approved)} approved groups`);
}

const handleCommand = require("./handle/handleCommand.js")({ api, Users, Threads, Currencies, models });
const handleCommandEvent = require("./handle/handleCommandEvent.js")({ api, Users, Threads, Currencies, models });
const handleReply = require("./handle/handleReply.js")({ api, Users, Threads, Currencies, models });
const handleReaction = require("./handle/handleReaction.js")({ api, Users, Threads, Currencies, models });
const handleEvent = require("./handle/handleEvent.js")({ api, Users, Threads, Currencies, models });
const handleCreateDatabase = require("./handle/handleCreateDatabase.js")({ api, Threads, Users, Currencies, models });


return (event) => {

// ===============================
// 🔥 GBAN — only when user calls the bot (prefix / mention / reply-to-bot)
// ===============================
if (["message", "message_reply"].includes(event.type)) {
  const body = (typeof event.body === "string" ? event.body.trim() : "");
  // check if it's a command (prefix) OR mentions bot OR reply to bot
  const isCommand = body && body.startsWith(global.config.PREFIX);
  const isMention = !!(event.mentions && event.mentions[api.getCurrentUserID()]);
  const isReplyToBot = !!(event.type === "message_reply" && event.messageReply && String(event.messageReply.senderID) === String(api.getCurrentUserID()));

  // if user is NOT calling the bot, do nothing
  if (!isCommand && !isMention && !isReplyToBot) {
    // allow normal group chat (no ban message, no logs)
  } else {
    // user is trying to use the bot — enforce GBAN
    if (global.globalBanUsers[event.senderID]) {
      const ban = global.globalBanUsers[event.senderID];

      // cooldown to avoid spam
      if (!global.gbanCooldown) global.gbanCooldown = {};
      if (Date.now() - (global.gbanCooldown[event.senderID] || 0) < 5000) {
        return; // ignore repeated attempts within 5s
      }
      global.gbanCooldown[event.senderID] = Date.now();

      // send a concise log to owner
      try {
        api.sendMessage(
          `⚠️ GLOBAL BAN ATTEMPT ⚠️\n\n` +
          `👤 UID: ${event.senderID}\n` +
          `🧵 Thread: ${event.threadID}\n` +
          `💬 Message: ${body || "[no text]"}\n` +
          `📛 Reason: ${ban.reason || "No reason"}\n` +
          `🗓 Date: ${ban.date || "Unknown"}`,
          global.config.OWNER
        );
      } catch (e) {}

      // notify the banned user with appeal instruction
      return api.sendMessage(
        `🚫 You are globally banned from using this bot.\n\n` +
        `📛 Reason: ${ban.reason || "No reason provided"}\n` +
        `🗓 Date: ${ban.date || "Unknown"}\n\n` +
        `If you think this is a mistake, appeal with:\n` +
        `Abdullah Or EMon-BHai`,
        event.threadID
      );
    }
  }
}




  switch (event.type) {
    case "message":
    case "message_reply":
    case "message_unsend":
      handleCreateDatabase({ event });
      handleCommand({ event });
      handleReply({ event });
      handleCommandEvent({ event });
      break;

    case "event":
      handleEvent({ event });
      break;

    case "message_reaction":
      handleReaction({ event });
      break;

    default:
      break;
  }
};

};