"use strict";

const utils = require("../utils");

const allowedProperties = {
  attachment: true,
  url: true,
  sticker: true,
  emoji: true,
  emojiSize: true,
  body: true,
  mentions: true,
  location: true,
};

module.exports = function (defaultFuncs, api, ctx) {

  // Upload attachments (stream) -> returns array of file metadata
  function uploadAttachment(attachments, cb) {
    const tasks = [];

    for (const file of attachments) {
      if (!utils.isReadableStream(file)) {
        return cb({ error: "Attachment must be a readable stream." });
      }
      const form = {
        upload_1024: file,
        voice_clip: "false"
      };
      tasks.push(
        defaultFuncs
          .postFormData("https://upload.facebook.com/ajax/mercury/upload.php", ctx.jar, form)
          .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
          .then((res) => {
            if (!res?.payload?.metadata) throw new Error("Upload failed");
            return res.payload.metadata[0];
          })
      );
    }

    Promise.all(tasks)
      .then((res) => cb(null, res))
      .catch((err) => {
        utils.error("uploadAttachment", err);
        cb(err);
      });
  }

  // Convert URL to share params
  function getUrl(url, cb) {
    const form = { image_height: 720, image_width: 720, uri: url };
    defaultFuncs
      .post("https://www.facebook.com/message_share_attachment/fromURI/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then((res) => {
        if (!res?.payload) return cb({ error: "Invalid URL" });
        cb(null, res.payload.share_data.share_params);
      })
      .catch((err) => {
        utils.error("getUrl", err);
        cb(err);
      });
  }

  // low-level sending
  function sendContent(form, threadID, isSingleUser, offlineID, cb) {
    if (Array.isArray(threadID)) {
      threadID.forEach((id, i) => (form[`specific_to_list[${i}]`] = "fbid:" + id));
      form[`specific_to_list[${threadID.length}]`] = "fbid:" + ctx.userID;
      form["client_thread_id"] = "root:" + offlineID;
    } else {
      if (isSingleUser) {
        form["specific_to_list[0]"] = "fbid:" + threadID;
        form["specific_to_list[1]"] = "fbid:" + ctx.userID;
        form["other_user_fbid"] = threadID;
      } else {
        form["thread_fbid"] = threadID;
      }
    }

    defaultFuncs
      .post("https://www.facebook.com/messaging/send/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then((res) => {
        if (!res?.payload) return cb({ error: "Failed sending message" });
        const action = res.payload.actions && res.payload.actions[0];
        if (!action) return cb({ error: "Failed to read send response" });
        cb(null, { threadID: action.thread_fbid, messageID: action.message_id, timestamp: action.timestamp });
      })
      .catch((err) => {
        utils.error("sendMessage", err);
        cb(err);
      });
  }

  function send(form, threadID, offlineID, cb, isGroup) {
    if (Array.isArray(threadID)) return sendContent(form, threadID, false, offlineID, cb);
    const single = String(threadID).length <= 15;
    return sendContent(form, threadID, single && !isGroup, offlineID, cb);
  }

  function handleLocation(msg, form, cb, next) {
    if (msg.location) {
      if (msg.location.latitude == null || msg.location.longitude == null) return cb({ error: "location property needs both latitude and longitude" });
      form["location_attachment[coordinates][latitude]"] = msg.location.latitude;
      form["location_attachment[coordinates][longitude]"] = msg.location.longitude;
      form["location_attachment[is_current_location]"] = !!msg.location.current;
    }
    next();
  }

  function handleSticker(msg, form, cb, next) {
    if (msg.sticker) form["sticker_id"] = msg.sticker;
    next();
  }

  function handleEmoji(msg, form, cb, next) {
    if (!msg.emoji) return next();
    const size = msg.emojiSize || "medium";
    if (!["small", "medium", "large"].includes(size)) return cb({ error: "emojiSize property is invalid" });
    if (form["body"]) return cb({ error: "body must be empty for emoji-only message" });
    form["body"] = msg.emoji;
    form["tags[0]"] = "hot_emoji_size:" + size;
    next();
  }

  function handleAttachment(msg, form, cb, next) {
    if (!msg.attachment) return next();
    form["image_ids"] = [];
    form["gif_ids"] = [];
    form["file_ids"] = [];
    form["video_ids"] = [];
    form["audio_ids"] = [];

    const items = Array.isArray(msg.attachment) ? msg.attachment : [msg.attachment];
    uploadAttachment(items, (err, files) => {
      if (err) return cb(err);
      files.forEach((file) => {
        const key = Object.keys(file)[0]; // e.g. image_id
        if (form[key + "s"]) form[key + "s"].push(file[key]);
      });
      next();
    });
  }

  function handleUrl(msg, form, cb, next) {
    if (!msg.url) return next();
    getUrl(msg.url, (err, params) => {
      if (err) return cb(err);
      form["shareable_attachment[share_type]"] = "100";
      form["shareable_attachment[share_params]"] = params;
      next();
    });
  }

  function handleMention(msg, form, cb, next) {
    if (!msg.mentions) return next();
    const emptyChar = "\u200E";
    form.body = emptyChar + (msg.body || "");
    msg.mentions.forEach((mention, i) => {
      const tag = mention.tag;
      const offset = (msg.body || "").indexOf(tag, mention.fromIndex || 0);
      form[`profile_xmd[${i}][offset]`] = offset + 1;
      form[`profile_xmd[${i}][length]`] = tag.length;
      form[`profile_xmd[${i}][id]`] = mention.id || 0;
      form[`profile_xmd[${i}][type]`] = "p";
    });
    next();
  }

  // final export: supports callback or promise
  return function sendMessage(msg, threadID, callback, replyToMessage, isGroup) {
    // allow (msg, threadID) -> returns Promise
    if (typeof callback === "undefined" && typeof replyToMessage === "undefined" && typeof isGroup === "undefined" && (typeof threadID === "function" || typeof threadID === "object" && typeof threadID.then === "function")) {
      // user accidentally passed callback as second param - not expected usage but safe-guard
      return threadID({ error: "Pass threadID as second argument." });
    }

    // normalize: if callback is a string then it's replyToMessage
    if (!replyToMessage && typeof callback === "string") {
      replyToMessage = callback;
      callback = undefined;
    }

    // promise wrapper
    let resolveFn, rejectFn;
    const promise = new Promise((resolve, reject) => {
      resolveFn = resolve;
      rejectFn = reject;
    });

    // ensure callback function exists
    if (!callback) {
      callback = function (err, data) {
        if (err) return rejectFn(err);
        return resolveFn(data);
      };
    }

    // validate inputs
    const msgType = utils.getType(msg);
    const threadType = utils.getType(threadID);
    if (msgType !== "String" && msgType !== "Object") return callback({ error: "Message should be string or object." });
    if (threadType !== "Array" && threadType !== "Number" && threadType !== "String") return callback({ error: "ThreadID should be number, string, or array." });

    if (msgType === "String") msg = { body: msg };

    const disallowed = Object.keys(msg).filter(p => !allowedProperties[p]);
    if (disallowed.length) return callback({ error: "Disallowed props: " + disallowed.join(", ") });

    const offlineID = utils.generateOfflineThreadingID();
    const form = {
      client: "mercury",
      action_type: "ma-type:user-generated-message",
      author: "fbid:" + ctx.userID,
      timestamp: Date.now(),
      timestamp_absolute: "Today",
      timestamp_relative: utils.generateTimestampRelative(),
      timestamp_time_passed: "0",
      is_unread: false,
      is_spoof_warning: false,
      source: "source:chat:web",
      "source_tags[0]": "source:chat",
      body: msg.body ? msg.body.toString() : "",
      offline_threading_id: offlineID,
      message_id: offlineID,
      threading_id: utils.generateThreadingID(ctx.clientID),
      has_attachment: !!(msg.attachment || msg.url || msg.sticker),
      signatureID: utils.getSignatureID(),
      replied_to_message_id: replyToMessage || null
    };

    // chain handlers
    try {
      handleLocation(msg, form, callback, () =>
        handleSticker(msg, form, callback, () =>
          handleAttachment(msg, form, callback, () =>
            handleUrl(msg, form, callback, () =>
              handleEmoji(msg, form, callback, () =>
                handleMention(msg, form, callback, () =>
                  send(form, threadID, offlineID, callback, isGroup)
                )
              )
            )
          )
        )
      );
    } catch (err) {
      // synchronous error -> callback/promise
      return callback(err);
    }

    return promise;
  };
};
