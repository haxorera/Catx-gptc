const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "imagine",
  version: "1.0.5",
  hasPermssion: 0,
  credits: "Amon Rakib",
  description: "Generate AI Image using AnbuInfosec API",
  commandCategory: "image",
  usePrefix: false,
  usages: "imagine [prompt]",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, args }) {
  const prompt = args.join(" ");
  if (!prompt) return api.sendMessage("⚠️ Prompt lagbe!\nExample: imagine cyberpunk cat", event.threadID, event.messageID);

  try {
    api.sendMessage("⏳ AI Image generating...\n(10-40s wait)", event.threadID);
    api.setMessageReaction("⏱️", event.messageID, () => {}, true);

    // Request image as Buffer
    const image = await axios.post(
      "https://api.anbuinfosec.live/api/v1/imagine",
      { prompt },
      { 
        responseType: "arraybuffer",
        headers: { "x-api-key": "hbdpjdezxcq5jcwcqtjjfp" }
      }
    );

    // Save temp image
    const filePath = path.join(__dirname, `cache_imagine_${Date.now()}.png`);
    fs.writeFileSync(filePath, Buffer.from(image.data));

    // Send to user
    api.sendMessage({
      body: `🧠 Prompt: ${prompt}`,
      attachment: fs.createReadStream(filePath)
    }, event.threadID, () => {
      fs.unlinkSync(filePath); // delete file after sending
      api.setMessageReaction("✅", event.messageID, () => {}, true);
    }, event.messageID);

  } catch (err) {
    api.sendMessage(
      "⚠️ Error:\n" + (err?.response?.statusText || err?.message || String(err)),
      event.threadID,
      event.messageID
    );
    api.setMessageReaction("⚠️", event.messageID, () => {}, true);
  }
};
