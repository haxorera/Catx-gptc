module.exports.config = {
  name: "leave",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "Mirai Team (No-canvas ver by Abdulla)",
  description: "Notifies when a member leaves or is removed from the group"
};

const moment = require("moment-timezone");

module.exports.run = async function ({ api, event, Users }) {
  try {
    const leftId = event.logMessageData.leftParticipantFbId;
    if (!leftId) return;

    const threadID = event.threadID;
    const authorId = event.author;

    // Member name
    const leftName =
      global.data.userName.get(leftId) ||
      await Users.getNameUser(leftId);

    // Author (who removed / who is the same as left)
    const authorName =
      global.data.userName.get(authorId) ||
      await Users.getNameUser(authorId);

    // Group info
    const threadInfo = await api.getThreadInfo(threadID);
    const threadName = threadInfo.threadName || "this group";
    const memberCount = threadInfo.participantIDs.length;

    // Time & session
    const time = moment.tz("Asia/Manila").format("HH:mm:ss - DD/MM/YYYY");
    const day = moment.tz("Asia/Manila").format("dddd");
    const hour = Number(moment.tz("Asia/Manila").format("HH"));

    const session =
      hour < 3 ? "midnight" :
      hour < 8 ? "early morning" :
      hour < 12 ? "noon" :
      hour < 17 ? "afternoon" :
      hour < 23 ? "evening" : "midnight";

    const isSelfLeave = leftId === authorId;

    const actionText = isSelfLeave
      ? "left the group by themselves"
      : "was removed from the group by an admin";

    const byText = isSelfLeave
      ? "They left on their own."
      : `Removed by: ${authorName}`;

    const body =
      `👋 ${leftName} ${actionText}.\n\n` +
      `👥 Group: ${threadName}\n` +
      `👤 Member: https://facebook.com/profile.php?id=${leftId}\n` +
      (isSelfLeave ? "" : `🛠 Admin: https://facebook.com/profile.php?id=${authorId}\n`) +
      `📊 Members remaining: ${memberCount}\n` +
      `🕒 Time: ${time} (${day}, ${session})\n` +
      `ℹ️ ${byText}`;

    const mentions = [
      { tag: leftName, id: leftId }
    ];

    if (!isSelfLeave) {
      mentions.push({ tag: authorName, id: authorId });
    }

    return api.sendMessage({ body, mentions }, threadID);
  } catch (e) {
    console.error("Leave command error:", e);
  }
};
