module.exports.config = {
  name: "join",
  eventType: ["log:subscribe"],
  version: "1.0.0",
  credits: "Mirai-Team (Modified by Abdulla)",
  description: "Simple welcome message without canvas"
};

const ADMIN = "YOUR_NAME";
const FB_LINK = "YOUR_FACEBOOK_LINK";

module.exports.run = async function ({ api, event, Users }) {
  const moment = require("moment-timezone");
  const time = moment.tz("Asia/Manila").format("HH:mm:ss - DD/MM/YYYY");
  const thu = moment.tz("Asia/Manila").format("dddd");

  let hours = moment.tz("Asia/Manila").format("HH");
  let session =
    hours < 3 ? "midnight" :
    hours < 8 ? "Early morning" :
    hours < 12 ? "noon" :
    hours < 17 ? "afternoon" :
    hours < 23 ? "evening" : "midnight";

  const { threadID } = event;
  const threadInfo = await api.getThreadInfo(threadID);
  const threadName = threadInfo.threadName;
  const { commands } = global.client;

  // Ensure event has participants
  if (!event.logMessageData.addedParticipants) return;

  // If bot is added
  if (event.logMessageData.addedParticipants.some(i => i.userFbId == api.getCurrentUserID())) {
    return api.sendMessage(
      `🤖 Bot added successfully in group **${threadName}** (${session})!\n\n` +
      `• Commands available: ${commands.size}\n` +
      `• Prefix: ${global.config.PREFIX}\n` +
      `• Version: ${global.config.version}\n` +
      `• Admin: ${ADMIN}\n` +
      `• Facebook: ${FB_LINK}\n\n` +
      `Type **${global.config.PREFIX}help** to view all commands.\n` +
      `⏰ Connected at: ${time} (${thu})`,
      threadID
    );
  }

  // Normal users joining
  try {
    let names = [];
    let mentions = [];
    let ids = [];

    for (let user of event.logMessageData.addedParticipants) {
      names.push(user.fullName);
      mentions.push({ tag: user.fullName, id: user.userFbId });
      ids.push(user.userFbId);
    }

    let authorName = await Users.getNameUser(event.author);
    let totalMembers = threadInfo.participantIDs.length;

    let welcomeMsg =
      `🎉 **Welcome to the group, ${names.join(", ")}!**\n\n` +
      `👥 Group: ${threadName}\n` +
      `🆔 Profile: https://facebook.com/profile.php?id=${ids.join(", ")}\n` +
      `➕ Added by: ${authorName}\n` +
      `⏰ Time: ${time} (${thu})\n` +
      `📌 You are now member number: ${totalMembers}\n` +
      `✨ Have a great ${session}!`;

    api.sendMessage(
      { body: welcomeMsg, mentions },
      threadID
    );

  } catch (err) {
    console.error(err);
  }
};
