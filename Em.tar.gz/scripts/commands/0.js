/**
 * @author EMON
 * @warn Do not edit credits
 */

module.exports.config = {
  name: "/",
  version: "1.2.7",
  permssion: 0,
  credits: "EMon-BHai",
  prefix: "false",
  description: "Bot Prefix Event",
  category: "NO PREFIX",
  hide: true,
  usages: "",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, Users, Threads }) {

  const request = global.nodemodule["request"];
  const fs = global.nodemodule["fs-extra"];
  const { threadID } = event;

  // Load config 
  const configPath = global.client.configPath;
  delete require.cache[require.resolve(configPath)];
  const config = require(configPath);
  const BOTNAME = config.BOTNAME;

  // Prefix
  const threadData = (await Threads.getData(String(threadID))).data || {};
  const prefix = threadData.PREFIX || config.PREFIX;

  // ✨ New Beautiful Random Texts
  const eventText = [
`✦—「 𝗘𝗠𝗼𝗻-𝗕𝗛𝗮𝗶 𝗕𝗢𝗧 」—✦  
🌸 জীবন তখনই সুন্দর হয়...  
যখন পাশে থাকে সত্যিকারের মানুষ!  
আর আমার পাশে আছো তুমি 💙`,

`✦—「 𝗘𝗠𝗼𝗻-𝗕𝗛𝗮𝗶 𝗕𝗢𝗧 」—✦  
🍁 মন ভাঙতে ভাঙতে শিখেছি—  
কাউকে বেশি গুরুত্ব দিলে  
নিজেকেই হারাতে হয় 🙂`,

`✦—「 𝗘𝗠𝗼𝗻-𝗕𝗛𝗮𝗶 𝗕𝗢𝗧 」—✦  
💫 কথা গুলো না বলা থাকলে  
হৃদয়ে সবচেয়ে বেশি বাজে...  
তবুও হাসি মুখে চলা— এটাই জীবন 💛`,

`✦—「 𝗘𝗠𝗼𝗻-𝗕𝗛𝗮𝗶 𝗕𝗢𝗧 」—✦  
🖤 একদিন সব ঠিকই হয়ে যাবে—  
কিন্তু সেই 'একদিন' আসার আগ পর্যন্ত  
হাল ছাড়বে না 💪🙂`,

`✦—「 𝗘𝗠𝗼𝗻-𝗕𝗛𝗮𝗶 𝗕𝗢𝗧 」—✦  
🌙 রাতগুলোই বুঝিয়ে দেয়—  
যাকে তোমার লাগে,  
সে তোমাকে লাগে না… 🙂`
  ];

  // Your Drive Video Link (Direct Download)
  const driveVideo = "https://drive.google.com/uc?export=download&id=1XiuoUXhS_bKCoOGLqaiZvZNn8HfNUFc1";

  const chosenText = eventText[Math.floor(Math.random() * eventText.length)];
  const filePath = __dirname + "/cache/EMon-BHai.mp4";

  const callback = () => {
    api.sendMessage(
      {
        body: `====「 ${BOTNAME} 」====\n\n${chosenText}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      () => fs.unlinkSync(filePath)
    );
  };

  request(encodeURI(driveVideo))
    .pipe(fs.createWriteStream(filePath))
    .on("close", callback);
};