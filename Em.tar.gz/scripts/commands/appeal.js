module.exports = {
  config: {
    name: "appeal",
    prefix: "true",
    category: "system",
    description: "Send an appeal message to bot admin",
  },

  run: async ({ api, event, args }) => {
    const uid = event.senderID;
    const thread = event.threadID;

    const content = args.join(" ");

    if (!content) {
      return api.sendMessage(
        "❗ **Usage:** appeal <your message>\nExample:\nappeal I was banned by mistake",
        thread,
        event.messageID
      );
    }

    // Load main owner + admins
    const mainOwner = global.config.OWNER;
    const admins = global.config.ADMINBOT || [];
    const notifyList = [mainOwner, ...admins];

    // Prepare message
    const msg =
      "📨 **NEW BAN APPEAL REQUEST**\n" +
      "──────────────────────────\n" +
      `👤 **User ID:** ${uid}\n` +
      `💬 **Group ID:** ${thread}\n\n` +
      `📝 **Appeal Message:**\n${content}\n\n` +
      "──────────────────────────\n" +
      "⚠️ Please review the appeal and take action if necessary.";

    // Send to all admins + owner
    for (const admin of notifyList) {
      try {
        await api.sendMessage(msg, admin);
      } catch (e) {}
    }

    // Confirm to user
    return api.sendMessage(
      "✅ **Your appeal has been submitted successfully.**\n" +
        "📩 Bot admin will review your request soon.\n" +
        "Please wait patiently.",
      thread,
      event.messageID
    );
  },
};
