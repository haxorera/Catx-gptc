// PART 1 - START
const { readdirSync: a, readFileSync: b, writeFileSync: c } = require("fs-extra");
const { join: d, resolve: e } = require("path");
const { execSync: f } = require("child_process");
const g = require("axios");
const h = require("../../Emon.json");
const i = require("chalk");

// ✅ FIX: package.json safe load
const packageJson = require("../../package.json");
const j = packageJson.dependencies || {};
const k = packageJson;

const l = require("fs");
const m = require("../system/login/index.js");
const n = require("moment-timezone");
const o = require("./Emonc.js");
const p = require("gradient-string");
const q = require("process");
const r = require("module").builtinModules;

global.client = new Object({
  commands: new Map(),
  events: new Map(),
  cooldowns: new Map(),
  eventRegistered: new Array(),
  handleSchedule: new Array(),
  handleReaction: new Array(),
  handleReply: new Array(),
  mainPath: q.cwd(),
  configPath: new String(),
  apiEmonPath: new String(),
  EmonPath: new String(),
  getTime: function (a) {
    switch (a) {
      case "seconds":
        return "" + n.tz("Asia/Dhaka").format("ss");
      case "minutes":
        return "" + n.tz("Asia/Dhaka").format("mm");
      case "hours":
        return "" + n.tz("Asia/Dhaka").format("hh");
      case "date":
        return "" + n.tz("Asia/Dhaka").format("DD");
      case "month":
        return "" + n.tz("Asia/Dhaka").format("MM");
      case "year":
        return "" + n.tz("Asia/Dhaka").format("YYYY");
      case "fullHour":
        return "" + n.tz("Asia/Dhaka").format("HH:mm:ss");
      case "fullYear":
        return "" + n.tz("Asia/Dhaka").format("DD/MM/YYYY");
      case "fullTime":
        return "" + n.tz("Asia/Dhaka").format("hh:mm:ss DD/MM/YYYY");
    }
  },
  timeStart: Date.now()
});

global.data = new Object({
  threadInfo: new Map(),
  threadData: new Map(),
  userName: new Map(),
  userBanned: new Map(),
  threadBanned: new Map(),
  commandBanned: new Map(),
  threadAllowNSFW: new Array(),
  allUserID: new Array(),
  allCurrenciesID: new Array(),
  allThreadID: new Array()
});

global.utils = require("./Emond.js");
global.loading = require("./Emonc.js");
global.nodemodule = new Object();
global.config = new Object();
global.Emon = new Object();
global.apiEmon = new Object();
global.configModule = new Object();
global.moduleData = new Array();
global.EmonData = new Array();
global.language = new Object();
global.account = new Object();

// ====== NEW: GBAN + APPEAL storage accessible to other modules ======
global.globalBanUsers = {};   // populated by GlobalBanSystem()
global.appealLogs = [];       // appeal history storage

const s = p.fruit;
const t = p("yellow", "lime", "green");
const u = p("#3446eb", "#3455eb", "#3474eb");
const v = "#3467eb";
const w = [];

if (w.length > 0) {
  console.log("commands with errors : ");
  w.forEach(({ command: a, error: b }) => {
    console.log(a + ": " + b);
  });
}

var x;
try {
  global.client.apiEmonPath = d(global.client.mainPath, "../configs/api.json");
  x = require(global.client.apiEmonPath);
} catch (a) {
  return;
}
try {
  for (const a in x) {
    global.apiEmon[a] = x[a];
  }
} catch (a) {
  return;
}

var y;
try {
  global.client.EmonPath = d(global.client.mainPath, "../configs/Emon.json");
  y = require(global.client.EmonPath);
} catch (a) {
  return;
}
try {
  for (const a in y) {
    global.Emon[a] = y[a];
  }
} catch (a) {
  return;
}

var z;
try {
  global.client.configPath = d(global.client.mainPath, "../../Emon.json");
  z = require(global.client.configPath);
  o.loader("deploying " + i.blueBright("Emon") + " file");
} catch (a) {
  return o.loader("cant read " + i.blueBright("Emon") + " file", "error");
}
try {
  for (const a in z) {
    global.config[a] = z[a];
  }
  o.loader("deployed " + i.blueBright("Emon") + " file");
} catch (a) {
  return o.loader("can't deploy " + i.blueBright("Emon") + " file", "error");
}

const { Sequelize: A, sequelize: B } = require("../system/database/index.js");

for (const a in j) {
  try {
    global.nodemodule[a] = require(a);
  } catch (a) {}
}

const C = b(__dirname + "/languages/" + (global.config.language || "en") + ".lang", {
  encoding: "utf-8"
}).split(/\r?\n|\r/);

const D = C.filter(a => a.indexOf("#") != 0 && a != "");

for (const a of D) {
  const bIdx = a.indexOf("=");
  const cKey = a.slice(0, bIdx);
  const dVal = a.slice(bIdx + 1, a.length);
  const eGroup = cKey.slice(0, cKey.indexOf("."));
  const fKey = cKey.replace(eGroup + ".", "");
  const gVal = dVal.replace(/\\n/gi, "\n");
  if (typeof global.language[eGroup] == "undefined") {
    global.language[eGroup] = new Object();
  }
  global.language[eGroup][fKey] = gVal;
}

global.getText = function (...a) {
  const b = global.language;
  if (!b.hasOwnProperty(a[0])) {
    throw new Error(__filename + " - not found key language : " + a[0]);
  }
  var c = b[a[0]][a[1]];
  if (typeof c === "undefined") {
    throw new Error(__filename + " - not found key text : " + a[1]);
  }
  for (var d = a.length - 1; d > 0; d--) {
    const bReg = RegExp("%" + d, "g");
    c = c.replace(bReg, a[d + 1]);
  }
  return c;
};

// =================== REMOTE ADMIN SYSTEM ===================
// Loads Admins.json from the raw GitHub URL and merges into global.config.ADMINBOT
async function loadRemoteAdmins() {
  try {
    const url = "https://raw.githubusercontent.com/sharifvau/Emon-Server/refs/heads/main/Admins.json";
    const res = await g.get(url, { timeout: 10000 });
    const adminRaw = res.data || [];

    // Convert [{ "Emon": "id" }, { "Abdullah": "uid" }] -> ["id", "uid"]
    const remoteAdmins = adminRaw
      .map(obj => {
        if (!obj) return null;
        // find first non-empty value
        const vals = Object.values(obj).filter(v => v && typeof v === "string" && v.trim().length > 0);
        return vals.length ? vals[0].trim() : null;
      })
      .filter(uid => uid);

    if (!Array.isArray(global.config.ADMINBOT)) {
      global.config.ADMINBOT = [];
    }

    // Merge + remove duplicates
    global.config.ADMINBOT = [...new Set([
      ...global.config.ADMINBOT,
      ...remoteAdmins
    ])];

    console.log(i.green(`[REMOTE ADMIN] Loaded ${remoteAdmins.length} remote admins.`));
  } catch (e) {
    console.log(i.red("[REMOTE ADMIN] Failed to load remote admin list:"), e.message || e);
  }
}

// =================== GLOBAL BAN SYSTEM (FULL FIXED) ===================
async function GlobalBanSystem() {
  try {
    const banURL = "https://raw.githubusercontent.com/sharifvau/Emon-Server/refs/heads/main/emonbotban.json";

    const res = await g.get(banURL, { timeout: 10000 });
    const remoteBanRaw = Array.isArray(res.data) ? res.data : [];

    // Convert array → map: { uid: {reason,date,addedBy} }
    const banList = {};

    for (const entry of remoteBanRaw) {
      if (!entry) continue;

      const uid = String(entry.uid || "").trim();

      // ignore invalid or empty UID
      if (!uid || uid.length < 5) continue;

      banList[uid] = {
        uid: uid,
        reason: entry.reason || "No reason provided",
        addedBy: entry.addedBy || "Unknown",
        date: entry.date || "Unknown Date"
      };
    }

    // expose to other modules (listen.js will use global.globalBanUsers)
    global.globalBanUsers = banList;

    const localAdmins =
      Array.isArray(global.config.ADMINBOT) ? global.config.ADMINBOT.map(id => String(id).trim()) : [];

    // Debug print
    console.log(i.yellow(`[GBAN] Loaded ${Object.keys(banList).length} banned users.`));

    for (const uid of localAdmins) {
      if (banList[uid]) {
        const ban = banList[uid];

        console.clear();
        console.log(i.red("            ╔═╗╔╦╗╔═╗╔╗╔  ╔╗ ╔═╗┌┬┐\n║╣ ║║║║ ║║║║  ╠╩╗║ ║ │ \n╚═╝╩ ╩╚═╝╝╚╝  ╚═╝╚═╝ ┴  "));
        console.log(i.green("۩❦۩¤═══════════════¤ GBAN ¤═══════════════¤۩❦۩"));
        console.log(i.green("[🚫] EMon-BHai-BOT-BAN: ") + i.red("You have been banned!"));
        console.log(i.green("[📛] Reason: ") + i.red(ban.reason));
        console.log(i.green("[🗓 ] Date:   ") + i.red(ban.date));

        // Fetch owner contact info
        try {
          const c = await g.get("https://raw.githubusercontent.com/sharifvau/Emon-Server/main/noti.json");
          console.log(i.green("[☎️ ] OWNER WP: ") + i.red(c.data.wp || "Unknown"));
          console.log(i.green("[🔰] OWNER FB: ") + i.red(c.data.fb || "Unknown"));
        } catch { }

        console.log(i.green("۩❦۩¤═════════════════¤ ❣ ¤══════════════════¤۩❦۩"));

        q.exit(0);
      }
    }

    console.log(i.green("[GLOBAL BAN] No banned admin detected."));

  } catch (err) {
    console.log(i.red("[GLOBAL BAN] Error loading ban list:"), err.message || err);
  }
}

// Auto-refresh ban list every 30 minutes
setInterval(() => {
  try {
    GlobalBanSystem();
  } catch (e) {
    console.log(i.red("[GBAN] Auto refresh failed:"), e.message || e);
  }
}, 1000 * 60 * 30); // 30 minutes
// PART 1 - END// PART 2 - START

// =================== UPDATE CHECKER ===================
async function E() {
  try {
    const aRes = await g.get("https://raw.githubusercontent.com/sharifvau/Emon-Server/main/noti.json");
    const bVer = aRes.data.v;
    if (k.version === bVer) {
      console.log(i.blue("version -") + " You Use EMon-BHai-Bot Update Version " + i.blueBright(bVer));
    } else {
      console.clear();
      const res = await g.get("https://raw.githubusercontent.com/sharifvau/Emon-Server/refs/heads/main/update.json");
      const data = res.data;

      // title
      console.log(i.blue("╔════════════════════════════════════╗"));
      console.log(i.blue("       EMon-Bhai-BOT UPDATE          "));
      console.log(i.blue("╚════════════════════════════════════╝\n"));

      // updated printed lines
      o(data.bot.name, "[ NAME ]");
      o(data.updates.latest_version, "[ VERSION ]");
      o(data.bot.description, "[ DESCRIPTION ]");
      o(data.updates.new_command, "[ NEW COMMAND ]");
      o(data.updates.update_status, "[ UPDATE STATUS ]");
      o(data.bot.owner, "[ OWNER ]");
      o(data.bot.links.github, "[ GITHUB ]");
      o(data.bot.links.replit, "[ REPLIT ]");

      console.log(i.green("\n[ CHANGELOG ]"));
      for (const line of data.updates.changelog || []) {
        console.log(" • " + line);
      }

      q.exit(0);
    }
  } catch (a) {
    console.error("EMon-BHai-BOT IS ON");
  }
}

// =================== GBAN CHECKER ===================
// Note: original F() logic is kept below in PART 2 where it's invoked/adjusted to call GlobalBanSystem()
// For now we keep the original F() name as a compatibility alias (will be overridden in PART 2 if needed).
async function F() {
  const aAdmins = global.config.ADMINBOT;
  try {
    const bRes = await g.get("https://raw.githubusercontent.com/sharifvau/Emon-Server/main/noti.json");
    const cRes = await g.get("https://raw.githubusercontent.com/sharifvau/Emon-Server/main/emonbotban.json");
    const dData = cRes.data;
    for (const c of aAdmins) {
      const aBan = dData[c];
      if (aBan) {
        console.clear();
        const cReason = aBan.reason;
        const dDate = aBan.date;
        console.log(i.blue("            ╔═╗╔╦╗╔═╗╔╗╔  ╔╗ ╔═╗┌┬┐\n║╣ ║║║║ ║║║║  ╠╩╗║ ║ │ \n╚═╝╩ ╩╚═╝╝╚╝  ╚═╝╚═╝ ┴  "));
        console.log(i.green("۩❦۩¤═══════════════¤ GBAN ¤═══════════════¤۩❦۩"));
        console.log(i.green("[🚫] EMon-Bhai-BOT-BAN:") + " " + i.red("You have been banned"));
        console.log(i.green("[📛] Reason:", "" + i.red("" + cReason)));
        console.log(i.green("[🗓 ] Date:", "" + i.red("" + dDate)));
        console.log(i.green("۩❦۩¤═══════════════¤ OWNER ¤═══════════════¤۩❦۩"));
        console.log(i.green("[☎️ ] OWNER WP:", "" + i.red(bRes.data.wp)));
        console.log(i.green("[🔰] OWNER FB:", "" + i.red(bRes.data.fb)));
        console.log(i.green("۩❦۩¤═════════════════¤ ❣ ¤══════════════════¤۩❦۩"));
        q.exit(0);
      }
    }
  } catch (a) {
    console.log("Error fetching or parsing JSON:", a);
  }
}

// PART 2 - END// PART 3 - START

try {
  if (!global.config.BOTNAME) {
    o.error("please enter your bot name in " + i.blueBright("Emon.json") + " file");
    q.exit(0);
  }
  if (!global.config.PREFIX) {
    o.error("please enter your bot prefix in " + i.blueBright("Emon.json") + " file");
  }
  if (global.config.OWNER != "100075290587473") {
    o.error("detected : Owner uid was changed at " + i.blueBright("Emon.json"));
    q.exit(0);
  }
  if (global.config.author != "Emon") {
    o.error("detected : author was changed at " + i.blueBright("Emon.json"));
    q.exit(0);
  }
  if (k.author != "Emon") {
    o.error("detected : author was changed at " + i.blueBright("package.json"));
    q.exit(0);
  }
  if (k.name != "EMon-BHai-Bot") {
    o.error("detected : project name was changed at " + i.blueBright("package.json"));
    q.exit(0);
  }
} catch (a) {
  return;
}

try {
  var G = e(d(global.client.mainPath, "../../Emonstate.json"));

  // FIXED: use global.Emon.encryptSt
  var H =
    (q.env.REPL_OWNER || q.env.PROCESSOR_IDENTIFIER) &&
    l.readFileSync(G, "utf8")[0] != "[" &&
    global.Emon.encryptSt
      ? JSON.parse(
          global.utils.decryptState(
            l.readFileSync(G, "utf8"),
            q.env.REPL_OWNER || q.env.PROCESSOR_IDENTIFIER
          )
        )
      : require(G);

  o.loader("deployed " + i.blueBright("Emonstate") + " file");
} catch (a) {
  console.clear();
  console.log(i.red("┓ ┏┓┏┓┳┳┓  ┏┓┳┓┳┓┏┓┳┓\n┃ ┃┃┃┓┃┃┃  ┣ ┣┫┣┫┃┃┣┫\n┗┛┗┛┗┛┻┛┗  ┗┛┛┗┛┗┗┛┛┗"));
  console.log();
  console.log("[❌] can't read " + i.blueBright("Emonstate") + " file");
  console.log("[🔰] go to home(" + i.green("Emon.md") + ")");
  console.log("[🔰] read " + i.blueBright("HOW TO GET " + i.green("Emonstate.json")));
  q.exit(0);
}

function I({ models: b }) {
  const eLogin = {
    appState: H
  };

  m(eLogin, async (err, gApi) => {
    if (err) {
      console.log(err);
      return q.exit(0);
    }

    gApi.setOptions(global.Emon.loginoptions);

    let lState = JSON.stringify(gApi.getAppState(), null, "\t");

    if ((q.env.REPL_OWNER || q.env.PROCESSOR_IDENTIFIER) && global.Emon.encryptSt) {
      lState = await global.utils.encryptState(
        lState,
        q.env.REPL_OWNER || q.env.PROCESSOR_IDENTIFIER
      );
      c(G, lState);
    } else {
      c(G, lState);
    }

    global.client.api = gApi;
    global.Emon.version = h.version;

    // ================================
    //      DEPLOY COMMANDS
    // ================================
    (async () => {
      const ePath = "../../scripts/commands";

      const hFiles = a(ePath).filter(
        file =>
          file.endsWith(".js") &&
          !file.includes("example") &&
          !((global.config.disabledcmds || []).includes(file))
      );

      console.clear();
      console.log(
        i.blue(
          "———————————————————————————————————————————\n" +
            "            DEPLOYING ALL COMMANDS\n" +
            "———————————————————————————————————————————\n"
        )
      );

      for (const aFile of hFiles) {
        try {
          const hModule = require(ePath + "/" + aFile);
          const { config: lCfg } = hModule;

          if (!lCfg?.category) {
            console.log(i.red("command - " + aFile + " category missing"));
            continue;
          }

          if (!lCfg?.prefix) {
            console.log(
              "command -",
              i.hex("#ff0000")(aFile) + ' missing "prefix" property.'
            );
            continue;
          }

          if (global.client.commands.has(lCfg.name || "")) {
            console.log(
              i.red("command - " + i.hex("#FFFF00")(aFile) + " is already deployed.")
            );
            continue;
          }

          // INSTALL MODULE DEPENDENCIES
          const { dependencies: mDeps, envConfig: nEnv } = lCfg;

          if (mDeps) {
            Object.entries(mDeps).forEach(([aDep, bVer]) => {
              if (j[aDep]) return;

              try {
                f("npm install --save " + aDep + (bVer ? "@" + bVer : ""), {
                  stdio: "inherit",
                  env: q.env,
                  shell: true,
                  cwd: d("../../node_modules")
                });

                require.cache = {};
              } catch (bErr) {
                const cMsg = "failed to install " + aDep + "\n";
                global.loading.err(i.hex("#ff7100")(cMsg), "command");
              }
            });
          }

          // APPLY MODULE ENV CONFIG
          if (nEnv) {
            const name = lCfg.name;

            global.configModule[name] = global.configModule[name] || {};
            global.Emon[name] = global.Emon[name] || {};

            for (const key in nEnv) {
              global.configModule[name][key] = global.Emon[name][key] ?? nEnv[key];
              global.Emon[name][key] = global.Emon[name][key] ?? nEnv[key];
            }

            var kConf = require("../configs/Emon.json");
            kConf[name] = nEnv;

            c(global.client.EmonPath, JSON.stringify(kConf, null, 4), "utf-8");
          }

          if (hModule.onLoad) {
            try {
              hModule.onLoad({ api: gApi, models: b });
            } catch (aErr) {
              throw new Error("unable to load onLoad()");
            }
          }

          if (hModule.handleEvent) {
            global.client.eventRegistered.push(lCfg.name);
          }

          global.client.commands.set(lCfg.name, hModule);

          global.loading(
            t("") + "successfully deployed " + i.blueBright(lCfg.name),
            "command"
          );
        } catch (bErr) {
          global.loading.err(
            i.hex("#ff7100")("") +
              "failed to deploy " +
              i.hex("#FFFF00")(aFile) +
              " " +
              bErr +
              "\n",
            "command"
          );
        }
      }
    })();

    // ================================
    //         DEPLOY EVENTS
    // ================================

    console.clear();
    (async () => {
      const ePath = d(global.client.mainPath, "../../scripts/events");

      const eFiles = a(ePath).filter(
        file =>
          file.endsWith(".js") &&
          !((global.config.disabledevents || []).includes(file))
      );

      console.log(
        i.blue(
          "\n———————————————————————————————————————————\n" +
            "             DEPLOYING ALL EVENTS\n" +
            "———————————————————————————————————————————\n"
        )
      );

      for (const aFile of eFiles) {
        try {
          const eModule = require(d(global.client.mainPath, "../../scripts/events", aFile));
          const { config: hCfg, onLoad: jOnLoad, run: kRun } = eModule;

          if (!hCfg || !hCfg.name || !kRun) {
            global.loading.err(
              i.hex("#ff7100")("") +
                " " +
                i.hex("#FFFF00")(aFile) +
                " invalid module format.",
              "event"
            );
            continue;
          }

          if (global.client.events.has(hCfg.name)) {
            global.loading.err(
              i.hex("#ff7100")("") +
                " " +
                i.hex("#FFFF00")(aFile) +
                " already deployed.",
              "event"
            );
            continue;
          }

          // INSTALL EVENT DEPENDENCIES
          if (hCfg.dependencies) {
            const missingDeps = Object.keys(hCfg.dependencies).filter(
              dep => !global.nodemodule[dep]
            );

            if (missingDeps.length) {
              const pkgList = missingDeps
                .map(dep => dep + (hCfg.dependencies[dep] ? "@" + hCfg.dependencies[dep] : ""))
                .join(" ");

              f("npm install --no-package-lock --no-save " + pkgList, {
                stdio: "inherit",
                env: q.env,
                shell: true,
                cwd: d("../../node_modules")
              });

              Object.keys(require.cache).forEach(key => delete require.cache[key]);
            }
          }

          // APPLY ENV CONFIG
          if (hCfg.envConfig) {
            const aCfg = (global.configModule[hCfg.name] ||= {});
            const bCfg = (global.Emon[hCfg.name] ||= {});

            for (const cKey in hCfg.envConfig) {
              aCfg[cKey] = bCfg[cKey] = hCfg.envConfig[cKey] || "";
            }

            c(
              global.client.EmonPath,
              JSON.stringify(
                {
                  ...require(global.client.EmonPath),
                  [hCfg.name]: hCfg.envConfig
                },
                null,
                2
              )
            );
          }

          if (jOnLoad) {
            await jOnLoad({ api: gApi, models: b });
          }

          global.client.events.set(hCfg.name, eModule);

          global.loading(
            t("") + "successfully deployed " + i.blueBright(hCfg.name),
            "event"
          );
        } catch (bErr) {
          global.loading.err(
            "" +
              i.hex("#ff0000")("") +
              i.blueBright(aFile) +
              " failed: " +
              bErr.message +
              "\n",
            "event"
          );
        }
      }
    })();

// PART 3 - END
// PART 4 - START

    console.log(
      i.blue(
        "\n———————————————————————————————————————————\n" +
          "              DEPLOYING BOT DATA\n" +
          "———————————————————————————————————————————\n"
      )
    );

    global.loading(
      t("") +
        "deployed " +
        i.blueBright("" + global.client.commands.size) +
        " commands and " +
        i.blueBright("" + global.client.events.size) +
        " events",
      "data"
    );

    global.loading(
      t("") +
        "deployed time : " +
        i.blueBright(((Date.now() - global.client.timeStart) / 1000).toFixed() + "s"),
      "data"
    );

    const mArg = {
      api: gApi,
      models: b
    };

    const nListen = require("../system/listen.js")(mArg);

    const pArg = {
      api: gApi
    };
    global.custom = require("../../Emon.js")(pArg);

    // FIXED LISTENER
    global.handleListen = gApi.listen(async (err, event) => {
      if (err) {
        console.log("Listen Error:", err);
        return;
      }

      if (!event) return;

      // ignore presence/read events
      if (["presence", "typ", "read_receipt"].includes(event.type)) return;

      return nListen(event);
    });
  });
}

// =====================================================================
//             DATABASE + REMOTE ADMIN + GLOBAL BAN CALL
// =====================================================================

(async () => {
  try {
    await B.authenticate();

    const aDb = {};
    const bChalk = require("chalk");

    aDb.Sequelize = A;
    aDb.sequelize = B;

    const cModels = require("../system/database/model.js")(aDb);

    o("deployed " + bChalk.blueBright("database") + " system", "Emon");

    // ⬇️  NEW SYSTEMS ADDED HERE  ⬇️
    await loadRemoteAdmins();   // REMOTE ADMIN SYSTEM
    await GlobalBanSystem();    // GLOBAL BAN CHECKER
    // ⬆️  NEW SYSTEMS ADDED HERE  ⬆️

    o("deployed " + bChalk.blueBright("GBAN") + " system", "Emon");

    E(); // update checker

    o("deploying " + bChalk.blueBright("login") + " system", "Emon");

    const dArg = {
      models: cModels
    };

    I(dArg);
  } catch (a) {
    o("can't deploy " + i.blueBright("database") + " system", "Emon");
  }
})();

// PART 4 - END